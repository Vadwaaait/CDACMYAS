global using INTEST.Services;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddTransient<IFinance, SI>();
var app = builder.Build();
app.UseStaticFiles();
app.MapPost("/DoInterest",DoInterest);

app.Run();



partial class Program{
//, IFinance interestobj

    public static async Task DoInterest(HttpRequest request, HttpResponse response, IFinance interestobj){
           


        try
        {
                 string amount=request.Form["uamount"];
            string Rate=request.Form["urate"];
            string Period=request.Form["uperiod"];

            int a=int.Parse(amount);
            int b=int.Parse(Period);
            int c=int.Parse(Rate);


            int ans = interestobj.GetInterest(a,b,c);
                 await response.WriteAsync(
                    $"<h1><center>Interest Chart</center><h1><hr><center><table border='1' style='width:40%'> <tr> <td>Amount</td> <td>{a}</td></tr>  <tr> <td>Period</td> <td>{b}</td></tr>  <tr> <td>Rate</td> <td>{c}</td></tr>  <tr> <td>Interest</td> <td>{ans}</td></tr></table></center>"
                    
            );
        }
        catch (System.Exception)
        {
                
               await response.WriteAsync(
                   $"you entered wrong input"
                   
                    
            );
        }


           

    }
}
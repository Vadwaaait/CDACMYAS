namespace INTEST.Services;

public interface IFinance
{
   public int GetInterest(int a, int b, int c);
}
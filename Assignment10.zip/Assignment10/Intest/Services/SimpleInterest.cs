namespace INTEST.Services;

public class SI : IFinance{

public int GetInterest(int a, int b, int c){

    int amount=a;
    int rate= b;
    int period=c;



    return (amount*period*rate)/100;
}

}